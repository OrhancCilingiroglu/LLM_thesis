# V4 — final test-split evaluation, how to run it

`v4_final_test_llama32_3b.ipynb` is generated from the executed V3 `no_role`
notebook by
[project/core/make_final_test_notebook.py](../../LLM_Thesis/project/core/make_final_test_notebook.py).
Do not hand-edit it; change the generator and regenerate:

```bash
python -m project.core.make_final_test_notebook
```

Generating from the V3 notebook rather than writing a new one is deliberate:
the tokenisation (`tokenize_completion_only`, `smart_truncate_code`), the
scoring (`score`), and the prompt renderer are the *same objects* the
validation numbers came from. A fresh notebook would be a second pipeline, and
its number would not belong in the same table.

## The configuration, and what fixed it

| axis | value | fixed by |
| --- | --- | --- |
| model | Llama-3.2-3B-Instruct | V1 — best model under 8B: 1st in the ≤3.5B class by +0.036, ahead of every 7B/9B tested, 0.010 behind the only model above it at 40% of its size |
| LoRA rank | 8 | V2 — rank comparison |
| learning rate | 5e-4 | V2 — best of the 7-cell grid, 0.682 |
| detection prompt | `no_role` | V3 — best weighted F1 (0.665 matched, 0.654 row mean), best macro F1 (0.487) and widest CWE coverage (96/120 classes), at the cost of a 10.7% false-positive rate against baseline's 0.4% |

No training runs. The adapter V3 already wrote is loaded from:

```
/content/drive/MyDrive/thesis_results/adapters_v3/llama32_3b_ground_truth_descendant_mpc15_ctx4096_lora_r8_a16_lr0.0005_prompt-no_role_nocomment
```

If that directory is not there, the config cell stops with a message rather
than silently training something.

## Run order

Run every cell top to bottom. Four things happen, in this order, and the order
matters:

1. **Majority-class floor and zero-shot on test.** Gives RQ1/RQ3 a test-split
   baseline beside the fine-tuned row. The base model is untuned, so this
   costs nothing in selection terms.
2. **Reproduction check on validation.** The adapter is loaded and re-evaluated
   on the *validation* split, then compared against V3's logged numbers
   (accuracy 0.648, weighted F1 0.665, macro F1 0.487, secure 0.893,
   vulnerable 0.478). Deviation above 0.010 raises and **the test split is not
   read**. This exists because the load path here differs slightly from V3's —
   V3 attached the adapter to a model that had been through
   `prepare_model_for_kbit_training`, this attaches it to a clean 4-bit model.
   The weights are the same; the check is what turns "should be identical" into
   "is identical".
3. **The test evaluation.** Matched prompt only. Writes per-item predictions to
   `predictions_final/` so any later re-scoring needs no second inference pass.
4. **Length-matched control.** Re-scores the stored predictions on a
   length-balanced subset. No inference. See below.

## The length-matched control

Secure samples in this corpus are longer than vulnerable ones, and the gap is
**wider on test than on validation**: median secure/vulnerable code length is
1.32 on test against 1.18 on val. A model that learned "longer means secure"
scores better on test for a reason unrelated to security.

The control pairs each vulnerable sample with an unused secure sample of
near-identical code length, best-first by relative gap, and re-scores. Measured
on the test split (character length, as a stand-in for tokens):

| tolerance | pairs | samples | median length ratio | mean ratio |
| --- | ---: | ---: | ---: | ---: |
| 0.02 | 387 | 774 / 1071 | 1.014 | 1.000 |
| **0.05** | **408** | **816 / 1071** | **1.010** | **1.000** |
| 0.10 | 412 | 824 / 1071 | 1.003 | 1.001 |

0.05 is the default: it keeps 76% of the split at a per-pair gap of at most
4.4%. Note that the naive "each vulnerable row takes its nearest unused secure
row" only reaches a median ratio of 1.11 on this data — the matching is
best-first for that reason.

The control reports the aggregate only. 408 pairs leave too little per-CWE
support for a per-label table.

## Read once

The notebook writes `thesis_results/final_test_receipt.json` the first time it
produces a headline number. On a later run it compares the configuration
against that receipt: an identical configuration is reproduction and is
allowed, a different one is refused with an explanation.

The guard is a convenience, not the rule. The rule is that the test number is
reported as it comes out. If it disappoints, that is the finding — changing a
setting and re-running would make the test split a second validation split, and
there is no third split.

## What to report afterwards

- the test row beside the validation row for the same configuration, both
  labelled with their split;
- the zero-shot test row, for the RQ1/RQ3 comparison;
- the length-matched number beside the headline, with the pair count;
- the standing limitations: `CONTEXT_LEN=4096` drops the supervised target for
  16.8% of training rows (V3 `no_role`: 638/3,803 train, 105/549 val), and
  every figure is accuracy against the strict tool-stack reference, not against
  ground truth.
